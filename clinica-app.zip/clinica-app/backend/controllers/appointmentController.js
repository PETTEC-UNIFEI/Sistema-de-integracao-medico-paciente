const Appointment = require('../models/Appointment');
const User = require('../models/User');

const createAppointment = async (req, res) => {
  const { doctorId, date, time } = req.body;
  const patientId = req.user._id;

  const doctor = await User.findById(doctorId);
  if (!doctor || doctor.role !== 'doctor') {
    res.status(404);
    throw new Error('Doctor not found');
  }

  const appointment = new Appointment({
    doctor: doctorId,
    patient: patientId,
    date,
    time,
  });

  const createdAppointment = await appointment.save();
  res.status(201).json(createdAppointment);
};

const getAppointmentsByDoctor = async (req, res) => {
  const appointments = await Appointment.find({ doctor: req.params.doctorId }).populate('patient', 'name email');
  res.json(appointments);
};

const getAppointmentsByPatient = async (req, res) => {
  const appointments = await Appointment.find({ patient: req.params.patientId }).populate('doctor', 'name email specialty');
  res.json(appointments);
};

module.exports = { createAppointment, getAppointmentsByDoctor, getAppointmentsByPatient };
