const express = require('express');
const { registerUser, authUser, getDoctors, getUserProfile } = require('../controllers/userController');
const { protect, admin } = require('../middleware/authMiddleware');
const router = express.Router();

router.post('/register', registerUser);
router.post('/login', authUser);
router.get('/doctors', protect, getDoctors);
router.get('/profile', protect, getUserProfile);

module.exports = router;
