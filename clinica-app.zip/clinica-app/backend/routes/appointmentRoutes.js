const express = require('express');
const { createAppointment, getAppointmentsByDoctor, getAppointmentsByPatient } = require('../controllers/appointmentController');
const { protect } = require('../middleware/authMiddleware');
const router = express.Router();

router.post('/', protect, createAppointment);
router.get('/doctor/:doctorId', protect, getAppointmentsByDoctor);
router.get('/patient/:patientId', protect, getAppointmentsByPatient);

module.exports = router;
